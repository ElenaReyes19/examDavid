<template>

  <div>
  <b-button v-b-modal.modal-1>Registro de vehiculo</b-button>

  <b-modal id="modal-1" title="Registro de vehiculo" pills card-header slot="header" v-b-scrollspy:nav-scroller>
    <form >
<div>
        <label for="campo1">Marca</label>
        <div>
        <input type="text" id="campo1" v-model="campo1"></div>

        <label for="campo1">Modelo</label>
            <div>
        <input type="text" id="campo1" v-model="campo2">
        </div>
        <label for="campo1">Año de fabricación</label>
        <div>
        <input type="text" id="campo1" v-model="campo2">
        </div>
        <label for="campo1">Número de serie</label>
        <div>
        <input type="text" id="campo1" v-model="campo2">
        </div>
        
    
    </div>
        
       
        <button type="submit">Enviar</button>
</form>
  </b-modal>
</div> 
</template>

<script>
export default {
    el: '#app',
  data: {
    errors: [],
    marca: '',
    model: '',
    serie: '',
    year: '',
  },
  methods:{
    checkForm: function (e) {
      e.preventDefault();

      this.errors = [];

      if (this.name === '') {
        this.errors.push('El nombre del producto es obligatorio.');
      } else {
        fetch(apiUrl + encodeURIComponent(this.name))
        .then(res => res.json())
        .then(res => {
          if (res.error) {
            this.errors.push(res.error);
          } else {
            // Podría redireccionar a una nueva URL, o hacer algo diferente
            alert('Ok!');
          }
        });
      }
    }
  }
}
</script>

<style>

</style>