<template>
  <b-breadcrumb :items="items">
  <div>
  <b-card
    title="Card Title"
    img-src="https://picsum.photos/600/300/?image=25"
    img-alt="Image"
    img-top
    tag="article"
    style="max-width: 20rem;"
    class="mb-2"
  >
    <b-card-text>
      Some quick example text to build on the card title and make up the bulk of the card's content.
    </b-card-text>

    <b-button href="#" variant="primary">Go somewhere</b-button>
  </b-card>
</div>
</b-breadcrumb>
</template>

<script>

  export default {
    data() {
      return {
        items: [
          {
            text: 'Home',
            to: { name: 'home' },
            href: '#Home'
          },
          {
            text: 'Formulario',
             path: '/Home',
             name: 'Home',
             component:()=> import('../components/Home.vue'),
    },
    {
            text: 'Paginación',
             path: '/Home',
             name: 'Home',
             component:()=> import('../components/Home.vue')
    },
      
        ]
      }
    }
  }
</script>