<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue';
import Hello from './components/Hello.vue';
</script>
<template>
  <main>
    <HelloWorld/>
      <div>
        <TheWelcome/>
      </div>
      <div>
        <Hello/>
      </div>

  </main>
 
</template>

<style scoped>

</style>
